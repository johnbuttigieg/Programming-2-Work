public class FirstBadOutput
{
   public static void main(String[] args)
   {
      System.out.println("First Jav application");
   }
}
