public class DebugOne1

   /* This program displays a greeting */
   public static void main(String[] args)
   {
      Systemoutprintl("Hello).
   }
